package com.packtpub;

public class Calculator {
    public int sum(int x, int y) {
        return x + y;
    }
}
